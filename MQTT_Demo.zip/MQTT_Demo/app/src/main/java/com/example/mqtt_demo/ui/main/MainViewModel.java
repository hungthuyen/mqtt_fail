package com.example.mqtt_demo.ui.main;

import android.provider.SyncStateContract;

import androidx.lifecycle.ViewModel;

import com.example.mqtt_demo.MQTT.MqttHelper;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttToken;

public class MainViewModel extends ViewModel {
    // TODO: Implement the ViewModel

}
